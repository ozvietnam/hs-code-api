import notesData from '../data/notes.json';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  const { chapter, heading } = req.query;

  if (!chapter && !heading) {
    return res.status(400).json({
      error: 'Cần tham số chapter (số chương) hoặc heading (mã nhóm 4 số)',
      vi_du: ['/api/notes?chapter=85', '/api/notes?heading=8509'],
      chapters_available: Object.keys(notesData).map(Number).sort((a,b)=>a-b),
    });
  }

  // Tra theo chương
  if (chapter) {
    const chap = String(parseInt(chapter));
    if (!notesData[chap]) {
      return res.status(404).json({
        found: false,
        message: `Không có chú giải cho Chương ${chapter}`,
      });
    }
    return res.status(200).json({
      found: true,
      chapter: parseInt(chap),
      loai: 'Chú giải chương',
      noi_dung: notesData[chap],
      nguon: 'Danh mục HHDM XNK Việt Nam - TT31/2022/TT-BTC',
    });
  }

  // Tra theo heading (mã 4 số) — trả về chú giải của chương chứa heading đó
  if (heading) {
    const code = heading.replace(/\./g, '').trim();
    const chapNum = String(parseInt(code.slice(0, 2)));
    if (!notesData[chapNum]) {
      return res.status(404).json({
        found: false,
        message: `Không có chú giải cho Chương ${chapNum} (từ heading ${heading})`,
      });
    }
    return res.status(200).json({
      found: true,
      heading: heading,
      chapter: parseInt(chapNum),
      loai: 'Chú giải chương',
      noi_dung: notesData[chapNum],
      nguon: 'Danh mục HHDM XNK Việt Nam - TT31/2022/TT-BTC',
    });
  }
}
