import taxData from '../data/tax.json';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  const { hs } = req.query;
  if (!hs) {
    return res.status(400).json({ error: 'Thiếu tham số hs. Ví dụ: /api/tax?hs=39261000' });
  }

  // Chuẩn hoá: bỏ dấu chấm, trim
  const code = hs.replace(/\./g, '').trim();

  // Tra chính xác 8 số
  if (taxData[code]) {
    const r = taxData[code];
    return res.status(200).json({
      found: true,
      hs: r.hs,
      mo_ta: r.vn,
      don_vi: r.dvt,
      thue: {
        nk_tt:   r.tt   || null,
        nk_mfn:  r.mfn  || null,
        vat:     r.vat  || null,
        acfta:   r.acfta || null,
        bvmt:    r.bvmt || null,
        giam_vat: r.giam_vat || null,
      },
      chinh_sach: r.cs || null,
      canh_bao_cs: r.cs ? true : false,
    });
  }

  // Không tìm thấy 8 số — thử tìm nhóm 6 số gần nhất
  const prefix6 = code.slice(0, 6);
  const related = Object.values(taxData)
    .filter(r => r.hs.startsWith(prefix6))
    .slice(0, 5)
    .map(r => ({ hs: r.hs, mo_ta: r.vn }));

  return res.status(404).json({
    found: false,
    message: `Không tìm thấy mã ${code}`,
    go_y_ma_lien_quan: related,
  });
}
